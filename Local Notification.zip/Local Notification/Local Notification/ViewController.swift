//
//  ViewController.swift
//  Local Notification
//
//  Created by MAC on 13/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController,UNUserNotificationCenterDelegate {
    let notificationCenter = UNUserNotificationCenter.current()
    
    @IBOutlet weak var timeDatepicker: UIDatePicker!
    @IBOutlet weak var timeTxt: UITextField!
    let dateformater = DateFormatter()

    override func viewDidLoad() {
        super.viewDidLoad()
        timeTxt.inputView = timeDatepicker
       
       
        notificationCenter.delegate = self
        notificationCenter.requestAuthorization(options: [.alert,.badge,.sound])
        { (success, error) in
            
        }
        // Do any additional setup after loading the view.
    }

    @IBAction func changeTime(_ sender: Any) {
        dateformater.dateFormat = "hh-mm a"
        timeTxt.text = dateformater.string(from: timeDatepicker.date)
    }
    
    @IBAction func clickToNotify(_ sender: Any) {
        let content = UNMutableNotificationContent()
        content.title = "Local Notification"
        content.body = "Heyy This is Notification Demo"
        
        let date = timeDatepicker.date
        let dateComp = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: date)
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComp, repeats: false)
//        let trigger = UNTimeIntervalNotificationTrigger.init(timeInterval: dateComp , repeats: false)
        let request = UNNotificationRequest.init(identifier: "notify", content: content, trigger: trigger)
        notificationCenter.add(request){ (error) in
//        print("\(error?.localizedDescription)")
        }
        
    }
   func  userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler(.alert)
    }
    
}

